<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
        class="bi bi-arrow-up-short"></i></a>
<script src="../../assets/vendors/purecounter/purecounter_vanilla.js"></script>
<script src="../../assets/vendors/aos/aos.js"></script>
<script src="../../assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../../assets/vendors/glightbox/js/glightbox.min.js"></script>
<script src="../../assets/vendors/isotope-layout/isotope.pkgd.min.js"></script>
<script src="../../assets/vendors/swiper/swiper-bundle.min.js"></script>
<script src="../../assets/vendors/php-email-form/validate.js"></script>
<script src="../../assets/js/index.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="../../assets/js/popper.min.js"></script>
<script src="../../assets/js/bootstrap.min.js"></script>
<script src="../../assets/js/owl.carousel.min.js"></script>
<script src="../../assets/js/main.js"></script>
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r121/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/vanta@latest/dist/vanta.fog.min.js"></script>
<script>
    const setVanta = () => {
        if (window.VANTA) {
            window.VANTA.FOG({
                el: document.querySelector(".s-page-1"),
                mouseControls: true,
                touchControls: true,
                gyroControls: false,
                minHeight: 200.0,
                minWidth: 200.0,
                highlightColor: 0xffc300,
                midtoneColor: 0xff1f00,
                lowlightColor: 0x2d00ff,
                baseColor: 0xffebeb,
            });
        }
    };
    document.addEventListener("DOMContentLoaded", setVanta);
</script> --}}

