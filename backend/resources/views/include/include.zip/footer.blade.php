<footer id="footer" class="footer">
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 footer-info">
                    <a href="home.html" class="logo d-flex align-items-center">
                        <img src="resources/images/TOMASInno-Center-Logo-High-Res.png" alt="" />
                        <span>i-BIBES</span>
                    </a>
                    <p>
                        The MinSU i-BIBES is the Technology Business Incubator
                        (TBI) of the Mindoro State University.
                    </p>
                    <div class="social-links mt-3">
                        <a href="#" class="twitter"><i
                                class="bi bi-twitter"></i></a>
                        <a href="https://web.facebook.com/MINSUiBIBES" class="facebook"><i
                                class="bi bi-facebook"></i></a>
                        <a href="#" class="instagram"><i
                                class="bi bi-instagram"></i></a>
                        <a href="mailto:minsuibibes@gmail.com" class="email"><i
                                class="bi bi-envelope-open-fill"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="copyright">
            &copy; Copyright
            <strong><span>2024 MinSU | i-BIBES</span></strong>. <br />
            Powered by MinSU | i-BIBES
        </div>
    </div>
</footer>
