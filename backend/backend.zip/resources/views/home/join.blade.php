@include('../include/.top')
<style>
    .navbar {
        background-color: #2E8B57;
    }
</style>
</head>
<body>
    @include('../include/.nav')
    @include('../Homepage/.login')

    <section>
        <div class="container" style="margin-top: 20vh">

        </div>
    @include('../include/.footer')
    @include('../include/.end')
