
<section class="events-section section-bg section-padding" id="section_4">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-12">
                <h2 class="mb-lg-3">Upcoming Events</h2>
            </div>
            <div class="row custom-block mb-3">
                <div class="col-lg-2 col-md-4 col-12 order-2 order-md-0 order-lg-0">
                    <div
                        class="custom-block-date-wrap d-flex d-lg-block d-md-block align-items-center mt-3 mt-lg-0 mt-md-0">
                        <h6 class="custom-block-date mb-lg-1 mb-0 me-3 me-lg-0 me-md-0">24</h6>
                        <strong class="text-white">Feb 2048</strong>
                    </div>
                </div>
                <div class="col-lg-4 col-md-8 col-12 order-1 order-lg-0">
                    <div class="custom-block-image-wrap">
                        <a href="event-detail.html">
                            <img src="{{ asset('assets/img/objective.jpg') }}" class="custom-block-image img-fluid"
                                alt="">
                            <i class="custom-block-icon bi-link"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 col-12 order-3 order-lg-0">
                    <div class="custom-block-info mt-2 mt-lg-0">
                        <a href="event-detail.html" class="events-title mb-3">Private activities</a>
                        <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua.</p>
                        <div class="d-flex flex-wrap border-top mt-4 pt-3">
                            <div class="mb-4 mb-lg-0">
                                <div class="d-flex flex-wrap align-items-center mb-1">
                                    <span class="custom-block-span">Location:</span>
                                    <p class="mb-0">National Center, NYC</p>
                                </div>
                                <div class="d-flex flex-wrap align-items-center">
                                    <span class="custom-block-span">Ticket:</span>
                                    <p class="mb-0">$250</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center ms-lg-auto">
                                <a href="event-detail.html" class="btn custom-btn">Buy Ticket</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row custom-block custom-block-bg">
                <div class="col-lg-2 col-md-4 col-12 order-2 order-md-0 order-lg-0">
                    <div
                        class="custom-block-date-wrap d-flex d-lg-block d-md-block align-items-center mt-3 mt-lg-0 mt-md-0">
                        <h6 class="custom-block-date mb-lg-1 mb-0 me-3 me-lg-0 me-md-0">28</h6>
                        <strong class="text-white">Feb 2048</strong>
                    </div>
                </div>
                <div class="col-lg-4 col-md-8 col-12 order-1 order-lg-0">
                    <div class="custom-block-image-wrap">
                        <a href="event-detail.html">
                            <img src="{{ asset('assets/img/objective.jpg') }}"
                                class="custom-block-image img-fluid" alt="">
                            <i class="custom-block-icon bi-link"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 col-12 order-3 order-lg-0">
                    <div class="custom-block-info mt-2 mt-lg-0">
                        <a href="event-detail.html" class="events-title mb-3">Group tournament activities</a>
                        <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua.</p>
                        <div class="d-flex flex-wrap border-top mt-4 pt-3">
                            <div class="mb-4 mb-lg-0">
                                <div class="d-flex flex-wrap align-items-center mb-1">
                                    <span class="custom-block-span">Location:</span>
                                    <p class="mb-0">National Center, NYC</p>
                                </div>
                                <div class="d-flex flex-wrap align-items-center">
                                    <span class="custom-block-span">Ticket:</span>
                                    <p class="mb-0">$350</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center ms-lg-auto">
                                <a href="event-detail.html" class="btn custom-btn">Buy Ticket</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
