<section class="about-section section-padding" id="section_2">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-12 text-center">
                <h2 class="mb-lg-5 mb-4">About i-BIBES</h2>
            </div>
            <div class="col-lg-5 col-12 me-auto mb-4 mb-lg-0">
                <h3 class="mb-3">MinSU i-BIBES History</h3>
                <p><strong>Established in 2024</strong>, the Mindoro State University (MinSU) i-BIBES was proudly
                    approved and funded by the Department of Science and Technology - PCIEERD. As the official
                    Technology Business Incubator (TBI) of MinSU, i-BIBES aims to empower innovation, support startups,
                    and foster a thriving entrepreneurial ecosystem in Mindoro.</p>
                <p>i-BIBES stands as a beacon for aspiring entrepreneurs and innovators, providing essential resources,
                    mentorship, and networking opportunities. With a vision to drive technological advancements and
                    regional economic growth, i-BIBES is committed to nurturing ideas and transforming them into
                    impactful ventures.</p>
                <p>As the first TBI of its kind in Mindoro, i-BIBES continues to build partnerships and create a
                    supportive environment for startups to flourish. Together, we inspire innovation and shape a
                    brighter future for our community and beyond.</p>
            </div>
            <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0 mb-md-0">
                <div class="member-block">
                    <div class="member-block-image-wrap">
                        <img src="{{ asset('assets/img/pres.webp') }}" class="member-block-image img-fluid"
                            alt="">
                        <ul class="social-icon">
                            <li class="social-icon-item">
                                <a href="#" class="social-icon-link bi-twitter"></a>
                            </li>
                            <li class="social-icon-item">
                                <a href="#" class="social-icon-link bi-whatsapp"></a>
                            </li>
                        </ul>
                    </div>
                    <div class="member-block-info d-flex align-items-center">
                        <h4>Dr. Enya Marie D. Apostol</h4>
                        <p class="ms-auto">SUC President III</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-12">
                <div class="member-block">
                    <div class="member-block-image-wrap">
                        <img src="{{ asset('assets/img/sir-randy.jpg') }}" class="member-block-image img-fluid"
                            alt="">
                        <ul class="social-icon">
                            <li class="social-icon-item">
                                <a href="#" class="social-icon-link bi-linkedin"></a>
                            </li>
                            <li class="social-icon-item">
                                <a href="#" class="social-icon-link bi-twitter"></a>
                            </li>
                        </ul>
                    </div>
                    <div class="member-block-info d-flex align-items-center">
                        <h4>Engr. Randy A. Joco</h4>
                        <p class="ms-auto">TBI Manager</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-bg-image">
    <svg viewBox="0 0 1265 144" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <path fill="rgba(255, 255, 255, 1)" d="M 0 40 C 164 40 164 20 328 20 L 328 20 L 328 0 L 0 0 Z" stroke-width="0">
        </path>
        <path fill="rgba(255, 255, 255, 1)" d="M 327 20 C 445.5 20 445.5 89 564 89 L 564 89 L 564 0 L 327 0 Z"
            stroke-width="0"></path>
        <path fill="rgba(255, 255, 255, 1)" d="M 563 89 C 724.5 89 724.5 48 886 48 L 886 48 L 886 0 L 563 0 Z"
            stroke-width="0"></path>
        <path fill="rgba(255, 255, 255, 1)" d="M 885 48 C 1006.5 48 1006.5 67 1128 67 L 1128 67 L 1128 0 L 885 0 Z"
            stroke-width="0"></path>
        <path fill="rgba(255, 255, 255, 1)" d="M 1127 67 C 1196 67 1196 0 1265 0 L 1265 0 L 1265 0 L 1127 0 Z"
            stroke-width="0"></path>
    </svg>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-12">
                <div class="section-bg-image-block">
                    <h2 class="mb-lg-3">Follow us on Facebook</h2>
                    <p>Stay updated with the latest news, events, and announcements from MINSU i-BIBES.</p>
                    <div id="fb-root"></div>
                    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v17.0">
                    </script>
                    <div class="fb-page" data-href="https://www.facebook.com/MINSUiBIBES" data-tabs="timeline"
                        data-width="500" data-height="300" data-small-header="true" data-adapt-container-width="true"
                        data-hide-cover="true" data-show-facepile="true">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <svg viewBox="0 0 1265 144" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <path fill="rgba(255, 255, 255, 1)" d="M 0 40 C 164 40 164 20 328 20 L 328 20 L 328 0 L 0 0 Z" stroke-width="0">
        </path>
        <path fill="rgba(255, 255, 255, 1)" d="M 327 20 C 445.5 20 445.5 89 564 89 L 564 89 L 564 0 L 327 0 Z"
            stroke-width="0"></path>
        <path fill="rgba(255, 255, 255, 1)" d="M 563 89 C 724.5 89 724.5 48 886 48 L 886 48 L 886 0 L 563 0 Z"
            stroke-width="0"></path>
        <path fill="rgba(255, 255, 255, 1)" d="M 885 48 C 1006.5 48 1006.5 67 1128 67 L 1128 67 L 1128 0 L 885 0 Z"
            stroke-width="0"></path>
        <path fill="rgba(255, 255, 255, 1)" d="M 1127 67 C 1196 67 1196 0 1265 0 L 1265 0 L 1265 0 L 1127 0 Z"
            stroke-width="0"></path>
    </svg>
</section>


<div class="section fun-facts">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="wrapper">
                    <div class="row">
                        <div class="col-lg-3 col-md-6">
                            <div class="counter">
                                <h2 class="timer count-title count-number" data-to="150" data-speed="1000"></h2>
                                <p class="count-text ">Happy Incubatees</p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="counter">
                                <h2 class="timer count-title count-number" data-to="804" data-speed="1000"></h2>
                                <p class="count-text "> Investors</p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="counter">
                                <h2 class="timer count-title count-number" data-to="50" data-speed="1000"></h2>
                                <p class="count-text ">Professional Mentors</p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="counter end">
                                <h2 class="timer count-title count-number" data-to="15" data-speed="1000"></h2>
                                <p class="count-text">Partners</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
