
<section class="contact-section section-padding" id="section_5">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-12">
                <form action="#" method="post" class="custom-form contact-form" role="form">
                    <h2 class="">Contact MinSU i-BIBES</h2>
                    <div class="row">
                        <div class="col-12">
                            <div class="form-floating">
                                <input type="text" name="full-name" id="full-name" class="form-control" placeholder="Full Name" required="">
                                <label for="floatingInput">Full Name</label>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-12">
                            <div class="form-floating">
                                <input type="email" name="email" id="email" pattern="[^ @]*@[^ @]*" class="form-control" placeholder="Email address" required="">
                                <label for="floatingInput">Email address</label>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-12">
                            <div class="form-floating">
                                <input type="text" name="phone" id="phone" class="form-control" placeholder="Phone Number" required="">
                                <label for="floatingInput">Phone Number</label>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-floating">
                                <input type="text" name="subject" id="subject" class="form-control" placeholder="Subject" required="">
                                <label for="floatingInput">Subject</label>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" id="message" name="message" placeholder="Describe message here"></textarea>
                                <label for="floatingTextarea">Message</label>
                            </div>
                            <button type="submit" class="form-control">Submit Form</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-6 col-12">
                <div class="contact-info mt-5">
                    <div style="margin-top: 60px" class="contact-info-item">
                        <div class="contact-info-body">
                            <strong>Alcate, Victoria | Oriental Mindoro</strong>
                            <p class="mt-2 mb-1">
                                <a href="tel: 010-020-0340" class="contact-link">
                                    (+63) 9123456789
                                </a>
                            </p>
                            <p class="mb-0">
                                <a href="mailto:ibibes@minsu.edu.ph" class="contact-link">
                                    ibibes@minsu.edu.ph
                                </a>
                            </p>
                        </div>
                        <div class="contact-info-footer">
                            <a
                                href="https://www.google.com/maps?q=13.157924794693157,121.18690863584995"
                                target="_blank"
                                style="text-decoration: none;">
                                Directions
                            </a>
                        </div>

                    </div>
                    <iframe
                    width="100%"
                    height="350"
                    frameborder="0"
                    style="border:0"
                    src="https://www.google.com/maps?q=13.157924794693157,121.18690863584995&z=14&output=embed"
                    allowfullscreen>
                </iframe>
                </div>
            </div>
        </div>
    </div>
</section>
