{{-- section-padding --}}
<section class="membership-section " id="section_3">
    <div class="container">
        <div class="services section" id="services">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="service-item">
                            <div class="icon">
                                <img width="80" height="80" src="https://img.icons8.com/emoji/100/bullseye.png"
                                    alt="bullseye" />
                            </div>
                            <div class="main-content">
                                <h4>Mission</h4>
                                <p>Empower start-ups by providing strong entrepreneurial ecosystem that drives
                                    innovation in Biosystem solutions, contributing to sustainable
                                    and resilient regional economic growth and development.</p>
                                {{-- <div class="main-button">
                                    <a href="#">Read More</a>
                                </div> --}}
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6s">
                        <div class="service-item">
                            <div class="icon">
                                <img width="80" height="80"
                                    src="https://img.icons8.com/color/100/ophthalmology.png" alt="ophthalmology" />
                            </div>
                            <div class="main-content">
                                <h4>Vision</h4>
                                <p>To be a leading business incubation hub in the MIMAROPA region advancing sustainable
                                    biosystems solutions and estahlishing innovative
                                    ventures that address challenges in agriculture, food systems, and bio-resource
                                    management.</p>
                                {{-- <div class="main-button">
                                    <a href="#">Read More</a>
                                </div> --}}
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="service-item">
                            <div class="icon">
                                <img width="80" height="80"
                                    src="https://img.icons8.com/external-flaticons-flat-flat-icons/100/external-objective-traditional-marketing-flaticons-flat-flat-icons.png"
                                    alt="external-objective-traditional-marketing-flaticons-flat-flat-icons" />
                            </div>
                            <div class="main-content">
                                <h4>Objectives</h4>
                                <ol>
                                    <li>Support startups in creating transformative biosystems solutions that convert agricultural biowastes into sustainable products, renewable bioenergy, innovative raw materials, food innovation, smart agriculture and fisheries management, and IoT for sustainable communities.</li>
                                    <li>Provide comprehensive support to startups, including prototyping services, mentorship, support infrastructure, business registration, seed funding, and market access.</li>
                                    <li>Build strong partnerships and a vibrant entrepreneurial ecosystem that connects innovators with resources, research institutions, and funding opportunities to sustain the growth of startups and ventures.</li>
                                </ol>
                                {{-- <div class="main-button">
                                    <a href="#">Read More</a>
                                </div> --}}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
