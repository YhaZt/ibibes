@include('../include/.top')
<style>
    .custom-btn-group {
    display: flex;
    align-items: flex-start;
}

.link-group a {
    display: block;
    text-align: left;
    color: var(--primary-color);
    text-decoration: none;
    margin-bottom: 5px;
}

.link-group a:hover {
    text-decoration: underline;
}

.btn.custom-btn {
    white-space: nowrap;
}

</style>
</head>
<body>
    @include('../include/.nav')
    @include('../Homepage/.login')
    <section class="hero-section d-flex justify-content-center align-items-center" id="section_1">
        <div class="section-overlay"></div>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path fill="#2E8B57" fill-opacity="1"
                d="M0,224L34.3,192C68.6,160,137,96,206,90.7C274.3,85,343,139,411,144C480,149,549,107,617,122.7C685.7,139,754,213,823,240C891.4,267,960,245,1029,224C1097.1,203,1166,181,1234,160C1302.9,139,1371,117,1406,106.7L1440,96L1440,0L1405.7,0C1371.4,0,1303,0,1234,0C1165.7,0,1097,0,1029,0C960,0,891,0,823,0C754.3,0,686,0,617,0C548.6,0,480,0,411,0C342.9,0,274,0,206,0C137.1,0,69,0,34,0L0,0Z">
            </path>
        </svg>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-12 mb-5 mb-lg-0">
                    <h2 class="text-white">Welcome to the MinSU i-BIBES</h2>
                    <h1 class="cd-headline rotate-1 text-white mb-4 pb-2">
                        <span>i-BIBES give</span>
                        <span class="cd-words-wrapper">
                            <b class="is-visible">Growth</b>
                            <b>Opportunities</b>
                            <b>Mentorship</b>
                        </span>
                    </h1>
                    <div class="custom-btn-group d-flex">
                        <a href="#section_2" class="btn custom-btn smoothscroll me-3">Our Story</a>
                        <div class="link-group">
                            <a href="/join-incubatee" class="btn custom-join link smoothscroll d-block mb-2">Become an Incubatee</a>
                            <a href="/join-mentor" class="btn custom-join link smoothscroll d-block mb-2">Become a Mentor</a>
                            <a href="/join-investor" class="btn custom-join link smoothscroll d-block">Become an Investor</a>
                        </div>
                    </div>

                </div>
                {{-- <div class="col-lg-6 col-12">
                <div class="ratio ratio-16x9">
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/MGNgbNGOzh8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                </div>
            </div> --}}
            </div>
        </div>
        {{-- <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path fill="#ffffff" fill-opacity="1"
                d="M0,224L34.3,192C68.6,160,137,96,206,90.7C274.3,85,343,139,411,144C480,149,549,107,617,122.7C685.7,139,754,213,823,240C891.4,267,960,245,1029,224C1097.1,203,1166,181,1234,160C1302.9,139,1371,117,1406,106.7L1440,96L1440,320L1405.7,320C1371.4,320,1303,320,1234,320C1165.7,320,1097,320,1029,320C960,320,891,320,823,320C754.3,320,686,320,617,320C548.6,320,480,320,411,320C342.9,320,274,320,206,320C137.1,320,69,320,34,320L0,320Z">
            </path>
        </svg> --}}
    </section>
    <div class="announcement-container" style="margin-top: 15vh;">
        <!-- Left Side: Text Content -->
        <div class="announcement-text">
          <h2>🌟 Exciting Announcement!</h2>
          <p>
            We are thrilled to introduce our latest project! Stay connected for more updates. Don't miss out on this amazing journey.
          </p>
          <button class="cta-button">Learn More</button>
        </div>

        <!-- Right Side: Image or Video -->
        <div class="announcement-media">
          <!-- Example Image -->
          <img src="{{ asset('assets/img/ibibes.jpg') }}" alt="Announcement Image" class="media-image">

          <!-- Example Video (Uncomment to use iframe instead of image) -->
          <!-- <iframe
            src="https://www.youtube.com/embed/your-video-id"
            title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            class="media-video"
          ></iframe> -->
        </div>
      </div>

      <div class="news-announcement">
        <div class="news-main">
            <img src="{{ asset('assets/img/ibibes.jpg') }}" alt="Main News" class="news-main-image">
            <div class="news-main-label">Breaking News: Major Event Happening Now</div>
            <p class="news-main-description">Stay updated with the latest developments as they unfold.</p>
        </div>
        <div class="news-sidebar">
            <div class="news-preview">
                <img src="{{ asset('assets/img/ibibes.jpg') }}" alt="Preview News 1" class="news-preview-image">
                <div class="news-preview-label">City Updates: Latest Developments</div>
                <p class="news-preview-description">Get the latest updates on the city, including new events and developments.</p>
            </div>
            <div class="news-preview">
                <img src="{{ asset('assets/img/ibibes.jpg') }}" alt="Preview News 2" class="news-preview-image">
                <div class="news-preview-label">Tech Innovations: What's New?</div>
                <p class="news-preview-description">Discover the newest tech gadgets and innovations shaping our future.</p>
            </div>
            <a href="/news" class="news-see-more">See More News</a>
        </div>
    </div>


    @include('../Homepage/.about-us')
    @include('../Homepage/.program')
    @include('../Homepage/.other')
    @include('../Homepage/.events')
    @include('../Homepage/.contact-us')
    </main>
    @include('../include/.footer')
    @include('../include/.end')
