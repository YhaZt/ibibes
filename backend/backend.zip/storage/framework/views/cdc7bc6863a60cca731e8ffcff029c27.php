<?php echo $__env->make('../include/.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .container {
        max-width: 100%;
        padding: 15px;
        margin: 0 auto;
    }

    .news-content {
        max-width: 100%;
        word-wrap: break-word;
        overflow: hidden;
    }

    .news-content img {
        max-width: 100%;
        height: auto;
        display: block;
        margin: 10px 0;
    }

    h1 {
        font-size: 2rem;
        line-height: 1.2;
        text-align: center;
    }

    @media (max-width: 768px) {
        h1 {
            font-size: 1.5rem;
        }

        .container {
            padding: 10px;
        }

        .news-content img {
            margin: 8px 0;
        }
    }
</style>


</head>

<body>

    <?php echo $__env->make('../include/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br>
    <br>
    <br>
    <div class="container">
        <h1><?php echo e($shownews->title); ?></h1>
        <?php $__currentLoopData = $shownews->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="tag__item"><i class="fas fa-tag mr-2"></i><?php echo e($tag->name); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="news-content">
            <?php echo $shownews->content; ?>

        </div>
    </div>

    <?php echo $__env->make('../include/.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('../include/.end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laragon\www\minsuibibes\New folder\backend\resources\views/home/news-page.blade.php ENDPATH**/ ?>