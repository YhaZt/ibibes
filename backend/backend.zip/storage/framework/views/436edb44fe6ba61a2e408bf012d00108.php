<script src=<?php echo e(asset('assets/js/jquery.min.js')); ?>></script>
<script src=<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>></script>
<script src=<?php echo e(asset('assets/js/jquery.sticky.js')); ?>></script>
<script src=<?php echo e(asset('assets/js/click-scroll.js')); ?>></script>
<script src=<?php echo e(asset('assets/js/animated-headline.js')); ?>></script>
<script src=<?php echo e(asset('assets/js/modernizr.js')); ?>></script>
<script src=<?php echo e(asset('assets/js/custom.js')); ?>></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>

<script>
    const currentYear = new Date().getFullYear();
    const startYear = 2024;
    const currentYearElement = document.getElementById('current-year');

    if (currentYear > startYear) {
        currentYearElement.textContent = ` - ${currentYear} `;
    }
</script>

<script>
    $(document).ready(function() {
        $('.partners-products').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            infinite: true,
            arrows: false,
            dots: false,
            autoplay: true,
            autoplaySpeed: 3000,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                    }
                }
            ]
        });
    });

    $(document).ready(function() {
        $('.products').slick({
            slidesToShow: 3,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 2000,
            arrows: false,
            dots: false,
            responsive: [{
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1
                    }
                }
            ]
        });
    });
    $(document).ready(function() {
        $('.testimonial-slider').slick({
            autoplay: true,
            autoplaySpeed: 1000,
            speed: 600,
            draggable: true,
            infinite: true,
            slidesToShow: 3,
            slidesToScroll: 1,
            arrows: false,
            dots: false,
            responsive: [{
                    breakpoint: 991,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                    }
                },
                {
                    breakpoint: 575,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                    }
                }
            ]
        });
    });
</script>
</body>

</html>
<?php /**PATH C:\laragon\www\minsuibibes\New folder\backend\resources\views////include//end.blade.php ENDPATH**/ ?>