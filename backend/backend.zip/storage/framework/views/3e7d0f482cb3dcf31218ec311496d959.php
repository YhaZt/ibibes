<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" href="https://htmljstemplates.com/static_files/images/favicon.png" />
    <script src="https://kit.fontawesome.com/dd5559ee21.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        a.nav-link {
            color: #343434;
            text-decoration: none;
            min-width: 80px;
        }

        a.nav-link.active {
            color: #000;
            font-weight: bold
        }

        #scrollContent {
            display: flex;
            justify-content: flex-start;
            align-items: center;
            width: 100%;
            height: 100%;
            white-space: nowrap;
        }

        #scrollContent>div {
            display: flex;
            animation: textScrollEffect 12s infinite linear;
        }

        @keyframes textScrollEffect {
            from {
                transform: translateX(0%);
            }

            to {
                transform: translateX(-50%);
            }
        }

        #subscribeButton:hover .icon path {
            fill: red;
        }
    </style>
    <title>i-BIBES</title>
    <meta name="description" content="A Daily news website navbar template">
    <script src="https://code.jquery.com/jquery-3.1.1.min.js"
        integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>


</head>

<body>
    <div role="navigation">
        <div class="p-3 bg-light">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-3 d-none d-md-block">
                        <div>
                            <span class="d-none d-lg-block">MinSU i-BIBES</span>
                            <small class="d-block">ᜡ-ᜪᜲᜪᜲᜰ᜴</small>
                        </div>
                        
                    </div>

                    <div class="col-lg-6 col-md-6 text-center">
                        <div class="display-6">News and Announcement</div>
                        <div class="text-warning" id="currentDateTime"></div>
                    </div>
                    <div class="col-lg-3 col-md-3 text-end d-none d-md-block">
                        <input class="form-control" placeholder="Search" />
                        <div class="mt-2"><strong>Trending :</strong> Big story tonight</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="border-bottom border-top" id="subNavContainer">
            <nav class="navbar navbar-expand-md">
                <div class="container-fluid">
                    <button class="navbar-toggler mx-auto" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false"
                        aria-label="Toggle navigation"><i class="fas fa-bars me-2"></i>
                        Menu</button>

                    <div class=" collapse navbar-collapse" id="navbarNavDropdown">
                        <ul class="navbar-nav mx-auto ">
                            <li class="nav-item">
                                <a class="nav-link mx-2 active" aria-current="page" href="#">News</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link mx-2" href="#">Current</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link mx-2" href="#">Local</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link mx-2" href="#">Sports</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link mx-2" href="#">Classified</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link mx-2" href="#">Contact Us</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link mx-2 dropdown-toggle" href="#" id="navbarDropdownMenuLink"
                                    role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Company
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <li><a class="dropdown-item" href="#">Blog</a></li>
                                    <li><a class="dropdown-item" href="#">About Us</a></li>
                                    <li><a class="dropdown-item" href="#">Contact us</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>

        <div class="border-bottom d-flex">
            <div>
                <div class="py-2 px-5 bg-danger text-white">Updates</div>
            </div>
            <div class="px-1" style="overflow:hidden">
                <div id="scrollContent" class="text-secondary">
                    <div>Lorem Ipsum is simply dummy text. Lorem Ipsum has been the industry's standard dummy text ever
                        since the 1500s. It was popularised in the 1960s with the release of Letraset sheets containing
                        Lorem Ipsum passages. It is a long
                        established fact that a reader will be distracted by the readable content of a page when looking
                        at its layout</div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function updateDateTime() {
            const now = new Date();
            const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            const dayName = days[now.getDay()];
            const monthName = months[now.getMonth()];
            const day = now.getDate();
            const year = now.getFullYear();
            let hours = now.getHours();
            const minutes = now.getMinutes().toString().padStart(2, '0');
            const seconds = now.getSeconds().toString().padStart(2, '0');
            const ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12;
            const formattedDate = `${dayName}, ${monthName} ${day}, ${year} ${hours}:${minutes}:${seconds} ${ampm}`;
            document.getElementById('currentDateTime').textContent = formattedDate;
        }
        setInterval(updateDateTime, 1000);
    </script>
</body>

</html>
<?php /**PATH C:\laragon\www\minsuibibes\New folder\backend\resources\views////news/nav.blade.php ENDPATH**/ ?>