<?php echo $__env->make('../news/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH C:\laragon\www\minsuibibes\New folder\backend\resources\views/news/index.blade.php ENDPATH**/ ?>