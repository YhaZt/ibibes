<?php echo $__env->make('../include/.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .navbar {
        background-color: #2E8B57;
    }
</style>
</head>
<body>
    <?php echo $__env->make('../include/.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('../Homepage/.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section>
        <div class="container" style="margin-top: 20vh">

        </div>
    <?php echo $__env->make('../include/.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('../include/.end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laragon\www\minsuibibes\New folder\backend\resources\views/Homepage/join.blade.php ENDPATH**/ ?>