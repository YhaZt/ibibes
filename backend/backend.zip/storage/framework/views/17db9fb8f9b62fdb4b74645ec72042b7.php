<?php echo $__env->make('../include/.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</head>

<body>
    <?php echo $__env->make('../include/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section id="pricing" class="pricing">
        <div class="container" data-aos="fade-up">
            <header class="section-header">
                <h2>Join Now</h2>
                <p>Be part of the MinSU i-BIBES!</p>
            </header>
            <div class="row justify-content-center" data-aos="fade-left">
                <div class="box col-lg-4 col-md-6 col-sm-12  pt-4 pb-5 px-4" data-aos="zoom-in" data-aos-delay="200">
                    <h3>Incubatee</h3>
                    <img src="<?php echo e(asset('assets/img/ibibes.jpg')); ?>" class="img-fluid px-4 mb-4" alt="" />
                    <a href="/join-incubatee" class="btn-buy incubatee">Join Now</a>
                </div>
                <div class="box col-lg-4 col-md-6 col-sm-12  pt-4 pb-5 px-4" data-aos="zoom-in" data-aos-delay="200">
                    <h3>Mentor</h3>
                    <img src="<?php echo e(asset('assets/img/ibibes.jpg')); ?>" class="img-fluid px-4 mb-4" alt="" />
                    <a href="/join-mentor" class="btn-buy incubatee">Join Now</a>
                </div>
                <div class="box col-lg-4 col-md-6 col-sm-12  pt-4 pb-5 px-4" data-aos="zoom-in" data-aos-delay="200">
                    <h3>Investor</h3>
                    <img src="<?php echo e(asset('assets/img/ibibes.jpg')); ?>" class="img-fluid px-4 mb-4" alt="" />
                    <a href="/join-investor" class="btn-buy incubatee">Join Now</a>
                </div>
            </div>
        </div>
    </section>

    <?php echo $__env->make('../include/.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('../include/.end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laragon\www\minsuibibes\New folder\backend\resources\views/home/join.blade.php ENDPATH**/ ?>