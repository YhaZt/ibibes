


<footer>
    <div class="container">
      <div class="col-lg-12">
        <p class="copyright-text">Copyright &copy; 2024  <span id="current-year"></span>i-BIBES</p>
      </div>
    </div>
  </footer>
<?php /**PATH C:\laragon\www\minsuibibes\New folder\backend\resources\views////include//footer.blade.php ENDPATH**/ ?>