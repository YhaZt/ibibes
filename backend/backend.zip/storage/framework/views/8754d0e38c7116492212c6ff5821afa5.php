<?php echo $__env->make('../include/.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link href="<?php echo e(asset('assets/css/home/news.css')); ?>" rel="stylesheet" />
<style>
    .pagination {
        margin-right: 0;
    }

    #dropdownPageSelector {
        margin-left: 10px;
        /* Optional, to add some space from the pagination */
    }
</style>

</head>

<body>
    <?php echo $__env->make('../include/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="light">
        <div class="container py-2">

            <div class="row">
                <!-- Left Side (MinSU i-BIBES Highlights) -->
                <div class="col-lg-8">
                    <div style="text-align: left" class="h1 text-dark" id="pageHeaderTitle">MinSU i-BIBES Highlights</div>
                    <div class="news-wrapper">
                        <?php $__currentLoopData = $newsItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $base64Image = null;
                                if (preg_match('/<img[^>]+src="([^"]+)"/', $news->content, $matches)) {
                                    $base64Image = $matches[1];
                                }
                            ?>
                            <article class="postcard light blue">
                                <a class="postcard__img_link">
                                    <img class="postcard__img"
                                        src="<?php echo e($base64Image ? $base64Image : 'default-image-url.jpg'); ?>"
                                        alt="Image of <?php echo e($news->title); ?>" />
                                </a>
                                <div class="postcard__text t-dark">
                                    <h1 class="postcard__title blue"><a href="<?php echo e(url('news/' . Crypt::encrypt($news->id))); ?>"><?php echo e($news->title); ?></a></h1>
                                    <div class="postcard__subtitle small">
                                        <time datetime="<?php echo e($news->publication_date); ?>">
                                            <i class="fas fa-calendar-alt mr-2"></i><?php echo e(\Carbon\Carbon::parse($news->publication_date)->format('l, M jS Y')); ?>

                                        </time>
                                    </div>
                                    <div class="postcard__bar"></div>
                                    <div class="postcard__preview-txt">
                                        <?php echo e(\Illuminate\Support\Str::limit(strip_tags($news->content), 150)); ?>

                                    </div>
                                    <ul class="postcard__tagbox">
                                        <?php $__currentLoopData = $news->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="tag__item"><i class="fas fa-tag mr-2"></i><?php echo e($tag->name); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if($newsItems->lastPage() > 1): ?>
                            <nav aria-label="Page navigation">
                                <ul class="pagination justify-content-center">
                                    <li class="page-item <?php echo e($newsItems->onFirstPage() ? 'disabled' : ''); ?>">
                                        <a class="page-link" href="<?php echo e($newsItems->url(1)); ?>" aria-label="First">
                                            First </a>
                                    </li>
                                    <li class="page-item <?php echo e($newsItems->onFirstPage() ? 'disabled' : ''); ?>">
                                        <a class="page-link" href="<?php echo e($newsItems->previousPageUrl()); ?>" aria-label="Previous">
                                            Previous </a>
                                    </li>
                                    <li class="page-item dropdown">
                                        <a class="page-link dropdown-toggle" href="#" id="currentPageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                            <?php echo e($newsItems->currentPage()); ?> of <?php echo e($newsItems->lastPage()); ?>

                                        </a>
                                        <div class="dropdown-menu p-3" aria-labelledby="currentPageDropdown">
                                            <form id="pageSelectorForm" action="<?php echo e(url('/news-announcement')); ?>" method="GET">
                                                <div class="form-group">
                                                    <label for="pageInput">Enter Page Number:</label>
                                                    <input type="number" class="form-control" id="pageInput" name="page" min="1" max="<?php echo e($newsItems->lastPage()); ?>" value="<?php echo e($newsItems->currentPage()); ?>" required>
                                                </div>
                                                <button type="submit" class="btn btn-primary mt-2">Go</button>
                                            </form>
                                        </div>
                                    </li>
                                    <li class="page-item <?php echo e($newsItems->hasMorePages() ? '' : 'disabled'); ?>">
                                        <a class="page-link" href="<?php echo e($newsItems->nextPageUrl()); ?>" aria-label="Next">
                                            Next
                                        </a>
                                    </li>
                                    <li class="page-item <?php echo e($newsItems->hasMorePages() ? '' : 'disabled'); ?>">
                                        <a class="page-link" href="<?php echo e($newsItems->url($newsItems->lastPage())); ?>" aria-label="Last">
                                            Last
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        <?php endif; ?>
                    </div>


                </div>
                <!-- Right Side (Latest News + Other Sections) -->
                <div class="col-lg-4">
                    <!-- Latest News Section -->
                    <div class="latest-news-section">
                        <h2 class="text-dark">Latest News</h2>
                        <ul class="latest-news-list">
                            <?php $__currentLoopData = $latestNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="news-item">
                                    <a href="<?php echo e(url('news/' . Crypt::encrypt($news->id))); ?>"><?php echo e($news->title); ?></a>
                                    <span class="news-date"><?php echo e(\Carbon\Carbon::parse($news->publication_date)->format('M d, Y')); ?></span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>


                    <!-- Top Views Section -->
                    <div class="top-views-section mt-4">
                        <h2 class="text-dark">Top Views</h2>
                        <ul class="top-views-list">
                            <?php $__currentLoopData = [['title' => 'Top Viewed Event 1', 'views' => '5k'], ['title' => 'Top Viewed Event 2', 'views' => '4.5k'], ['title' => 'Top Viewed Event 3', 'views' => '4k'], ['title' => 'Top Viewed Event 4', 'views' => '3.8k'], ['title' => 'Top Viewed Event 5', 'views' => '3.5k']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topView): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="top-views-item">
                                    <a href="#"><?php echo e($topView['title']); ?></a>
                                    <span class="news-date"><?php echo e($topView['views']); ?> Views</span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                    <!-- Important News Section -->
                    <div class="important-news-section mt-4">
                        <h2 class="text-dark">Important News</h2>
                        <ul class="important-news-list">
                            <?php $__currentLoopData = $importantNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="important-news-item">
                                    <a href="<?php echo e(url('news/' . Crypt::encrypt($news->id))); ?>"><?php echo e($news->title); ?></a>
                                    <span class="news-date"><?php echo e(\Carbon\Carbon::parse($news->publication_date)->format('M d, Y')); ?></span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                    <!-- Milestone Update Section -->
                    <div class="milestone-update-section mt-4">
                        <h2 class="text-dark">Milestone Updates</h2>
                        <ul class="milestone-update-list">
                            <?php $__currentLoopData = [['title' => 'System Milestone: 100k Users', 'date' => 'Sep 11, 2024'], ['title' => 'Milestone: 50k Requests Processed', 'date' => 'Sep 9, 2024'], ['title' => 'New Record: Fastest PR Approval', 'date' => 'Sep 6, 2024'], ['title' => 'Achievement: ISO Certification', 'date' => 'Sep 4, 2024'], ['title' => 'Milestone: 10 Years of Service', 'date' => 'Sep 2, 2024']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $milestone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="milestone-update-item">
                                    <a href="#"><?php echo e($milestone['title']); ?></a>
                                    <span class="news-date"><?php echo e($milestone['date']); ?></span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <?php echo $__env->make('../include/.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const previewTxts = document.querySelectorAll('.postcard__preview-txt');
            previewTxts.forEach(function(previewTxt) {
                if (previewTxt.innerHTML.trim() === '') return;
                const fullText = previewTxt.innerHTML;
                if (previewTxt.scrollHeight > previewTxt.clientHeight) {
                    const seeMoreBtn = document.createElement('span');
                    seeMoreBtn.classList.add('see-more-btn');
                    seeMoreBtn.textContent = 'See more';
                    previewTxt.parentNode.insertBefore(seeMoreBtn, previewTxt.nextSibling);
                    seeMoreBtn.addEventListener('click', function() {
                        if (previewTxt.classList.contains('expanded')) {
                            previewTxt.classList.remove('expanded');
                            seeMoreBtn.textContent = 'See more';
                        } else {
                            previewTxt.classList.add('expanded');
                            seeMoreBtn.textContent = 'See less';
                        }
                    });
                }
            });
        });
    </script>
    <?php echo $__env->make('../include/.end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laragon\www\minsuibibes\New folder\backend\resources\views/home/news.blade.php ENDPATH**/ ?>