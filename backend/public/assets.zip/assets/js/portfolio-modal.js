
    // Get all elements with the class name 'myImg'
var images = document.getElementsByClassName("myImg");

// Get all elements with the class name 'btn-secondary'
var closeButtons = document.getElementsByClassName("btn-secondary");

// Get all elements with the class name 'modal'
var modals = document.getElementsByClassName("modal");

// Loop through each image
for (var i = 0; i < images.length; i++) {
    // Assign a click event handler to each image
    images[i].onclick = function(index) {
        return function() {
            // Display the corresponding modal
            modals[index].style.display = "block";
        };
    }(i);

    // Assign a click event handler to each close button
    closeButtons[i].onclick = function(index) {
        return function() {
            // Close the corresponding modal
            modals[index].style.display = "none";
        };
    }(i);
    
    
    
}

   
